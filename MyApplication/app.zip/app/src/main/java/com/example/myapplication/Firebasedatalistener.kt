package com.example.myapplication

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError

interface FirebaseDataListener {
    fun onDataFetched(dataSnapshot: DataSnapshot, email: String, password:String): Boolean
    fun onCancelled(error: DatabaseError)
}
