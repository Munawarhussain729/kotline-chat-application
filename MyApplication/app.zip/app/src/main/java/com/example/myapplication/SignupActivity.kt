package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import java.lang.System.err

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup)

        val emailEditText = findViewById<EditText>(R.id.email)
        val nameEditText = findViewById<EditText>(R.id.name)
        val passwordEditText = findViewById<EditText>(R.id.password)

        var database = FirebaseDatabase.getInstance().getReference("user")

        findViewById<TextView>(R.id.SignUp).setOnClickListener {

            val name = nameEditText.text.toString()
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if(name.isEmpty()){
                nameEditText.error = "Please enter a name"
            }
            if(email.isEmpty()){
                emailEditText.error = "Please enter an Email"
            }
            if(password.isEmpty()){
                passwordEditText.error = "Please enter a Password"
            }

            val userId = database.push().key!!
//            Log.d("SignUpActivity", "Name: $name, Email: $email, Password: $password")

            val user = UserModel(userId,name,email,password)
//            Log.d("SignUpActivity", "Name: $user, Email: $database, Password: $password")

            database.child(userId).setValue(user).addOnCompleteListener{
//                Log.d("SignUpActivity", "Name: $name, Email: $email, Password: $password")

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }.addOnFailureListener{ err -> Toast.makeText(this, "Error ${err.message}", Toast.LENGTH_LONG).show()}

/*
*/
        }
    }


}
