package com.example.myapplication

import java.time.LocalDateTime

data class Message (private val message: String, private val sender: String, private val person: String, private val time: LocalDateTime) {
    fun getMessage (): String {
        return message
    }
    fun getTime (): LocalDateTime {
        return time
    }
    fun getSender (): String {
        return sender
    }
    fun getPerson (): String {
        return person
    }
}