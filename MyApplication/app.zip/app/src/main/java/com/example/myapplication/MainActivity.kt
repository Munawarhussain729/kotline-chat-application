package com.example.myapplication

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.database.*

class MainActivity : AppCompatActivity(), FirebaseDataListener  {
    private var mFirebaseAnalytics: FirebaseAnalytics? = null
    private lateinit var database: DatabaseReference
    private var isUserExists:Boolean = false

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signin)

//        database = FirebaseDatabase.getInstance().getReference("user")

        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.password)

        findViewById<TextView>(R.id.SignIn).setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            Log.d("SignInActivity", "Email: $email")
            Log.d("SignInActivity", "Password: $password")

            if(email.isEmpty()){
                emailEditText.error = "Please enter an Email"
            }
            if(password.isEmpty()){
                passwordEditText.error = "Please enter a Password"
            }
            fetchDataFromFirebase(email=emailEditText.text.toString(), password = passwordEditText.text.toString()){ userExists ->
                if (userExists) {
                    // User exists, perform the desired action
                    val intent = Intent(this, Conversation::class.java)
                    startActivity(intent)
                } else {
                    emailEditText.error = "Please enter a Correct Email"
                    passwordEditText.error = "Please enter a Correct Password"
                    // User doesn't exist, display an error message or take appropriate action
                }
            }


            //   val intent = Intent(this, Conversation::class.java)
//                startActivity(intent)


        }
        findViewById<TextView>(R.id.SignUp).setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
        }

    }

    private fun fetchDataFromFirebase(email: String, password: String, callback: (Boolean) -> Unit) {
        val database = FirebaseDatabase.getInstance().getReference("user")
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val UserExists = onDataFetched(snapshot, email, password)
                callback(UserExists)
            }


            override fun onCancelled(error: DatabaseError) {
                onCancelled(error)
            }
        })
    }
    override fun onDataFetched(dataSnapshot: DataSnapshot, email: String, password: String): Boolean  {
        val users: Any? = dataSnapshot.value

        if (users is Map<*, *>) {
            for ((key, value) in users) {
                val userEmail = (value as? Map<*, *>)?.get("userEmail") as? String
                val userPassword = (value as? Map<*, *>)?.get("userPassword") as? String

                // Perform your operations with userEmail and userPassword
                if (userEmail != null && userPassword != null) {
                  // User exists
                    if (userEmail == email && userPassword == password) {

                        isUserExists = true
                        return isUserExists
                    }

                }
            }
        }
        return isUserExists
    }




    override fun onCancelled(error: DatabaseError) {
        TODO("Not yet implemented")
    }

}
