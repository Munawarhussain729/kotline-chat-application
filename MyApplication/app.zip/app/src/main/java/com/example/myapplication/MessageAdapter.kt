package com.example.myapplication

import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.RecyclerView
import java.time.format.DateTimeFormatter

class MessageAdapter(private val MessageList: ArrayList<Message>, private val currentUser: String): RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        return when (viewType) {
            VIEW_TYPE_USER -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.message_layout, parent, false)
                MessageViewHolder(view)
            }
            VIEW_TYPE_DUMMY -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.message_reply, parent, false)
                MessageViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type: $viewType")
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if (MessageList[position].getSender() == currentUser) VIEW_TYPE_USER else VIEW_TYPE_DUMMY
    }

    override fun getItemCount(): Int {
        return MessageList.size
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.time.text = MessageList[position].getTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        holder.msg.text = MessageList[position].getMessage()
        holder.sender.text = MessageList[position].getSender()
    }

    class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val time:TextView = itemView.findViewById(R.id.time)
        val msg:TextView = itemView.findViewById(R.id.message)
        val sender:TextView = itemView.findViewById(R.id.sender)
    }

    companion object {
        private const val VIEW_TYPE_USER = 1
        private const val VIEW_TYPE_DUMMY = 2
    }
}