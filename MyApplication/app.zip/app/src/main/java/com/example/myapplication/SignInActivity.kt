import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import com.example.myapplication.R
import com.example.myapplication.SignupActivity
import com.example.myapplication.UserModel
import com.google.firebase.database.*

class SignInActivity : AppCompatActivity() {
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signin)

        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.password)

        database = FirebaseDatabase.getInstance().getReference("user")

        findViewById<TextView>(R.id.SignIn).setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            val query: Query = database.orderByChild("email").equalTo(email)
            query.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    var userFound = false
                    var userId = ""
                    var userName = ""

                    for (snapshot in dataSnapshot.children) {
                        val user = snapshot.getValue(UserModel::class.java)
                        if (user != null && user.userPassword == password) {
                            userFound = true
                            userId = snapshot.key.toString()
                            userName = user.userName.toString()
                            break
                        }
                    }

                    if (userFound) {
                        Log.d("SignInActivity", "User found! ID: $userId, Name: $userName")
                        // Add your desired logic here when the user is correct
                    } else {
                        Log.d("SignInActivity", "User not found or incorrect credentials")
                        // Add your desired logic here when the user is not found or credentials are incorrect
                    }
                }

                override fun onCancelled(databaseError: DatabaseError) {
                    Log.e("SignInActivity", "Error: ${databaseError.message}")
                }
            })
        }

//        findViewById<TextView>(R.id.SignUp).setOnClickListener {
//            val intent = Intent(this, SignupActivity::class.java)
//            startActivity(intent)
//        }
    }
}
