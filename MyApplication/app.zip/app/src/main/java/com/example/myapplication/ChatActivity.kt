package com.example.myapplication

//=====================================  UI LAYER  ===========================================


import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.time.LocalDateTime


class ChatActivity : AppCompatActivity() {
    lateinit var message: RecyclerView
    lateinit var messageList: ArrayList<Message>
    lateinit var sendButton: Button
    lateinit var sendText: EditText
    lateinit var person: String
    lateinit var personLabel: TextView
    lateinit var dbHandler: MessageHandler

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.chat_layout)

        // finds out the person to chat
        person = intent.getStringExtra("person")!!.toString()
        personLabel = findViewById(R.id.personName)
        personLabel.text = person

        // connect db and get messages
        dbHandler = MessageHandler(this)
        messageList = ArrayList()
        messageList.addAll(dbHandler.getData(person))

        // attach adapter
        val adapter = MessageAdapter(messageList, "Me")

        message = findViewById(R.id.message)
        message.layoutManager = LinearLayoutManager(this)
        message.adapter = adapter

        adapter.notifyItemInserted(messageList.size - 1)
        message.scrollToPosition(messageList.size - 1)

        sendButton = findViewById(R.id.button)
        sendText = findViewById(R.id.text)
        sendButton.setOnClickListener {
            val messageText = sendText.text.toString()
            if (messageText.isNotBlank()) {
                val userMessage = Message(messageText, "Me", person, LocalDateTime.now())
                messageList.add(userMessage)
                adapter.notifyItemInserted(messageList.size - 1)
                sendText.setText("")
                dbHandler.insertData(userMessage)

                val replyMessage = Message("This is a dummy reply.", person, person, LocalDateTime.now())
                messageList.add(replyMessage)
                adapter.notifyItemInserted(messageList.size - 1)
                dbHandler.insertData(replyMessage)

                message.scrollToPosition(messageList.size - 1)
            }
        }
    }
}