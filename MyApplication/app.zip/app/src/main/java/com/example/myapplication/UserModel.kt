package com.example.myapplication

data class UserModel(
    var userId: String? = null,
    var userName: String? = null,
    var userEmail: String? = null,
    var userPassword: String? = null
)
