package com.example.myapplication
//=====================================  DATA LAYER  ==========================================
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.widget.Toast
import androidx.annotation.RequiresApi
import java.time.LocalDateTime

const val DATABASE_NAME = "localdb"
const val TABLE_NAME = "Messages"
const val COL_ID = "Id"
const val COL_PERSON = "Person"
const val COL_MESSAGE = "Message"
const val COL_SENDER = "Sender"
const val COL_DATETIME = "DateTime"


class MessageHandler (private val context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, 1){
    override fun onCreate(p0: SQLiteDatabase?) {
        val sql = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_PERSON + " VARCHAR(50), " +
                COL_MESSAGE + " VARCHAR(256), " +
                COL_DATETIME + " VARCHAR(50), " +
                "$COL_SENDER VARCHAR(50) );\n"
        p0?.execSQL(sql)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        TODO("Not yet implemented")
    }


    // ===============================  BUSINESS LAYER  ============================================

    @Throws(Exception::class)
    @RequiresApi(Build.VERSION_CODES.O)
    fun insertData(message: Message) {
        val db = this.writableDatabase
        var contentValues = ContentValues()
        contentValues.put(COL_PERSON, message.getPerson())
        contentValues.put(COL_MESSAGE, message.getMessage())
        contentValues.put(COL_DATETIME, message.getTime().toString())
        contentValues.put(COL_SENDER, message.getSender())

        val result = db.insert(TABLE_NAME, null, contentValues)
        if (result == (-1).toLong()) throw Exception()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun getData(person: String) : ArrayList<Message> {
        var data = ArrayList<Message>()
        val db = this.readableDatabase
        val cursor = db.query(TABLE_NAME, arrayOf(COL_PERSON, COL_MESSAGE, COL_DATETIME, COL_SENDER), "$COL_PERSON = ?", arrayOf(person), null, null, null)
        with(cursor) {
            while (moveToNext()) {
                val sender = getString(getColumnIndexOrThrow(COL_SENDER))
                val message = getString(getColumnIndexOrThrow(COL_MESSAGE))
                val date = getString(getColumnIndexOrThrow(COL_DATETIME))
                data.add(Message(message, sender, person, LocalDateTime.parse(date)))
            }
        }
        cursor.close()
        return data
    }
}