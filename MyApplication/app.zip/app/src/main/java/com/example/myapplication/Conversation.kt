    package com.example.myapplication

    import android.os.Build
    import androidx.appcompat.app.AppCompatActivity
    import android.os.Bundle
    import android.view.View
    import android.widget.Button
    import android.widget.EditText
    import android.widget.Toast
    import androidx.annotation.RequiresApi
    import androidx.recyclerview.widget.LinearLayoutManager
    import androidx.recyclerview.widget.RecyclerView
    import com.google.firebase.database.DatabaseReference
    import com.google.firebase.database.FirebaseDatabase
    import java.time.LocalDateTime

    class Conversation : AppCompatActivity()  {
        private lateinit var chat: RecyclerView
        private lateinit var chats: ArrayList<String>

        @RequiresApi(Build.VERSION_CODES.O)
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            chats = ArrayList()
            chats.add("Ali")
            chats.add("Adam")
            chats.add("Ahil")
            chats.add("Hamza")

            val adapter = PersonAdapter(chats)
            chat = findViewById(R.id.person)
            chat.layoutManager = LinearLayoutManager(this)
            chat.adapter = adapter
        }
    }